<?php
$servername="localhost";
$username="username";
$password="rootpassword";
$conn=new mysqli($servername,$username,$password);
?>