<div id="container">
<div id="animate_1" class="divanimate">
<img id="image_1" class="a" src=".jpeg">
<img id="cover_1" class="imgcover">
</div><div id="animate_2" class="divanimate">
<img id="image_2" class="a" src="#">
<img id="cover_2" class="imgcover">
</div><div id="animate_3" class="divanimate">
<img id="image_3" class="a" src="#">
<img id="cover_3" class="imgcover">
</div><div id="animate_4" class="divanimate">
<img id="image_4" class="a" src="#">
<img id="cover_4" class="imgcover">
</div><div id="animate_5" class="divanimate">
<img id="image_5" class="a" src="#">
<img id="cover_5" class="imgcover">
</div><div id="animate_6" class="divanimate">
<img id="image_6" class="a" src="#">
<img id="cover_6" class="imgcover">
</div><div id="animate_7" class="divanimate">
<img id="image_7" class="a" src="#">
<img id="cover_7" class="imgcover">
</div><div id="animate_8" class="divanimate">
<img id="image_8" class="a" src="#">
<img id="cover_8" class="imgcover">
</div><div id="animate_9" class="divanimate">
<img id="image_9" class="a" src="#">
<img id="cover_9" class="imgcover">
</div><div id="animate_10" class="divanimate">
<img id="image_10" class="a" src="#">
<img id="cover_10" class="imgcover">
</div><div id="animate_11" class="divanimate">
<img id="image_11" class="a" src="#">
<img id="cover_11" class="imgcover">
</div><div id="animate_12" class="divanimate">
<img id="image_12" class="a" src="#">
<img id="cover_12" class="imgcover">
</div><div id="animate_13" class="divanimate">
<img id="image_13" class="a" src="#">
<img id="cover_13" class="imgcover">
</div><div id="animate_14" class="divanimate">
<img id="image_14" class="a" src="#">
<img id="cover_14" class="imgcover">
</div><div id="animate_15" class="divanimate">
<img id="image_15" class="a" src="#">
<img id="cover_15" class="imgcover">
</div><div id="animate_16" class="divanimate">
<img id="image_16" class="a" src="#">
<img id="cover_16" class="imgcover">
</div><div id="animate_17" class="divanimate">
<img id="image_17" class="a" src="#">
<img id="cover_17" class="imgcover">
</div><div id="animate_18" class="divanimate">
<img id="image_18" class="a" src="#">
<img id="cover_18" class="imgcover">
</div><div id="animate_19" class="divanimate">
<img id="image_19" class="a" src="#">
<img id="cover_19" class="imgcover">
</div><div id="animate_20" class="divanimate">
<img id="image_20" class="a" src="#">
<img id="cover_20" class="imgcover">
</div><div id="animate_21" class="divanimate">
<img id="image_21" class="a" src="#">
<img id="cover_21" class="imgcover">
</div><div id="animate_22" class="divanimate">
<img id="image_22" class="a" src="#">
<img id="cover_22" class="imgcover">
</div><div id="animate_23" class="divanimate">
<img id="image_23" class="a" src="#">
<img id="cover_23" class="imgcover">
</div><div id="animate_24" class="divanimate">
<img id="image_24" class="a" src="#">
<img id="cover_24" class="imgcover">
</div><div id="animate_25" class="divanimate">
<img id="image_25" class="a" src="#">
<img id="cover_25" class="imgcover">
</div>
</div>



$_POST['answer'] = preg_replace('/\s*/', '', $_POST['answer']);
// convert the string to all lowercase
$_POST['answer'] = strtolower($_POST['answer']);