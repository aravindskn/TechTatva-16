<?php

define('DB_HOST', 'localhost');
define('DB_NAME', 'quiz');
define('DB_USER', 'root');
define('DB_PASSWORD', 'badaya1234');
define('DB_CHARSET', 'utf8');

